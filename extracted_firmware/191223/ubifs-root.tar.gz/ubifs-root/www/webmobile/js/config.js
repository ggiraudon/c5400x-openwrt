
/*
 * 配置项
 */
suCommon.factory('$config', function(){
    return {
        PRINTER_SUPPORT: true
    }
});