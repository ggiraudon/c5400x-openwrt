(function($){

	$.su = $.su || {};
	$.su.CHAR = {
       PROTAL :{ 
           SUCCESS:"Đăng nhập thành công!",
           FAILED:"Đăng nhập thất  bại!",
           WELCOME:"Chào mừng",
           PASSWORD:"Mật mã",
           LOGIN:"Đăng nhập",
           ACCEPT_TERMS_OF_USE:"Tôi chấp nhận <a class=\"link\" href=\"#\" target=\"_blank\">Điều khoản sử dụng</a>"
},
       ERROR :{ 
           "00000001":"Mục bắt buộc",
           "00000002":"Định dạng không hợp lệ."
		}
	};

})(jQuery);

					
