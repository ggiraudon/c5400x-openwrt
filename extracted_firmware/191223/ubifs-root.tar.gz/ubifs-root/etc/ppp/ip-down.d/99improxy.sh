#!/bin/sh -e

[ -x /etc/init.d/improxy ] && /etc/init.d/improxy restart
